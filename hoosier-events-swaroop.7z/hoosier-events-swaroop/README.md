# SE-Team4-HoosierEvents
Event Management System for Indiana University of Bloomington

Contact the administrators fpr downloading or using the code. No write access to public other than collaborators. Maintain clean and good code collaboration standards.
