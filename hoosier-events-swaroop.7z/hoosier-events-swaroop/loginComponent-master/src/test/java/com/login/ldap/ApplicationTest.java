package com.login.ldap;

public class ApplicationTest {
}
