package com.login.ldap.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.login.ldap.model.Users;
public interface UsersRepo extends JpaRepository<Users,Long> {

}
