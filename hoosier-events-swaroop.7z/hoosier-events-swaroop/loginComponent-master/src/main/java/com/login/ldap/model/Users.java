package com.login.ldap.model;

import java.util.Set;

import javax.management.relation.Role;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name = "User_Details")
public class Users {



    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(name = "Username")
    private String Username;

    @Column(name = "Full_Name")
    private String Full_Name;


    @Column(name = "Passkey")
    private String Passkey;

    @Column(name = "Phone")
    private String Phone;

    @Column(name = "Address")
    private String Address;

    @Column(name = "User_Type")
    private String User_Type;

    @Column(name = "Sec_Ques")
    private String Sec_Ques;

    @Column(name = "Sec_Ans")
    private String Sec_Ans;


    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "user_role", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> roles;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getFull_Name() {
        return Full_Name;
    }

    public void setFull_Name(String Full_Name) {
        this.Full_Name = Full_Name;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public String getPassword() {
        return Passkey;
    }

    public void setPassword(String password) {
        this.Passkey = password;
    }


    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }
    public String getUser_Type() {
        return User_Type;
    }

    public void setUser_Type(String User_Type) {
        this.User_Type = User_Type;
    }

    public String getSec_Ques() {
        return Sec_Ques;
    }

    public void setSec_Ques(String Sec_Ques) {
        this.Sec_Ques = Sec_Ques;
    }

    public String getSec_Ans() {
        return Sec_Ans;
    }

    public void setSec_Ans(String Sec_Ans) {
        this.Sec_Ans = Sec_Ans;
    }

}

